// Data store for drivers and dustbins using localStorage
export interface Driver {
  id: number;
  name: string;
  phone: string;
  email: string;
  status: "active" | "break" | "offline";
  currentRoute: string;
  location: string;
  completedToday: number;
  efficiency: number;
  vehicleId: string;
  address: string;
  emergencyContact: string;
  licenseNumber: string;
  experience: string;
}

export interface Dustbin {
  id: string;
  location: string;
  fillLevel: number;
  batteryLevel: number;
  signalStrength: number;
  lastEmptied: string;
  status: "critical" | "warning" | "good";
  temperature: number;
  coordinates: { lat: number; lng: number };
  installDate: string;
  model: string;
  capacity: number;
}

const DRIVERS_STORAGE_KEY = 'smart_waste_drivers';
const DUSTBINS_STORAGE_KEY = 'smart_waste_dustbins';

// Driver operations
export const getDrivers = (): Driver[] => {
  try {
    const stored = localStorage.getItem(DRIVERS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

export const saveDrivers = (drivers: Driver[]): void => {
  localStorage.setItem(DRIVERS_STORAGE_KEY, JSON.stringify(drivers));
};

export const addDriver = (driver: Driver): void => {
  const drivers = getDrivers();
  drivers.push(driver);
  saveDrivers(drivers);
};

// Dustbin operations
export const getDustbins = (): Dustbin[] => {
  try {
    const stored = localStorage.getItem(DUSTBINS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

export const saveDustbins = (dustbins: Dustbin[]): void => {
  localStorage.setItem(DUSTBINS_STORAGE_KEY, JSON.stringify(dustbins));
};

export const addDustbin = (dustbin: Dustbin): void => {
  const dustbins = getDustbins();
  dustbins.push(dustbin);
  saveDustbins(dustbins);
};