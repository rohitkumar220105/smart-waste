import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { MapPin, Trash2, Battery, Wifi, Navigation } from "lucide-react";
import { useState } from "react";

const MapView = () => {
  const [selectedBin, setSelectedBin] = useState<any>(null);
  
  const dustbins = [
    {
      id: "BIN-A45",
      location: "Main Street & 1st Ave",
      fillLevel: 95,
      batteryLevel: 78,
      signalStrength: 85,
      lastEmptied: "2024-01-20",
      status: "critical",
      temperature: 22,
      coordinates: { lat: 40.7128, lng: -74.0060 }
    },
    {
      id: "BIN-B12", 
      location: "Park Avenue Plaza",
      fillLevel: 87,
      batteryLevel: 92,
      signalStrength: 90,
      lastEmptied: "2024-01-19",
      status: "warning",
      temperature: 21,
      coordinates: { lat: 40.7589, lng: -73.9851 }
    },
    {
      id: "BIN-C33",
      location: "City Center Mall",
      fillLevel: 92, 
      batteryLevel: 85,
      signalStrength: 78,
      lastEmptied: "2024-01-20",
      status: "critical",
      temperature: 24,
      coordinates: { lat: 40.7505, lng: -73.9934 }
    },
    {
      id: "BIN-D78",
      location: "Elm Street Park",
      fillLevel: 45,
      batteryLevel: 95,
      signalStrength: 88,
      lastEmptied: "2024-01-21",
      status: "good", 
      temperature: 20,
      coordinates: { lat: 40.7282, lng: -74.0776 }
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "critical": return "destructive";
      case "warning": return "warning";
      case "good": return "success";
      default: return "secondary";
    }
  };

  const getMarkerColor = (status: string) => {
    switch (status) {
      case "critical": return "bg-destructive";
      case "warning": return "bg-warning";
      case "good": return "bg-success";
      default: return "bg-secondary";
    }
  };

  const getBatteryColor = (level: number) => {
    if (level > 50) return "text-success";
    if (level > 20) return "text-warning";
    return "text-destructive";
  };

  const getSignalColor = (strength: number) => {
    if (strength > 70) return "text-success";
    if (strength > 40) return "text-warning";
    return "text-destructive";
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Map View</h1>
          <p className="text-muted-foreground">Interactive map showing all dustbin locations and status</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Navigation className="h-4 w-4" />
            Center Map
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[700px]">
        {/* Map Container */}
        <div className="lg:col-span-2">
          <Card className="h-full shadow-card">
            <CardContent className="p-0 h-full">
              <div className="relative w-full h-full bg-gradient-to-br from-accent/20 to-primary/10 rounded-lg flex items-center justify-center">
                {/* Simulated Map with Markers */}
                <div className="relative w-full h-full overflow-hidden rounded-lg">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-green-50 opacity-80"></div>
                  
                  {/* Street Grid Simulation */}
                  <svg className="absolute inset-0 w-full h-full opacity-20">
                    <defs>
                      <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
                        <path d="M 50 0 L 0 0 0 50" fill="none" stroke="gray" strokeWidth="1"/>
                      </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#grid)" />
                  </svg>

                  {/* Dustbin Markers */}
                  {dustbins.map((bin, index) => (
                    <div
                      key={bin.id}
                      className={`absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2 
                                 transition-all duration-200 hover:scale-110 z-10`}
                      style={{
                        left: `${25 + (index * 20)}%`,
                        top: `${30 + (index * 15)}%`
                      }}
                      onClick={() => setSelectedBin(bin)}
                    >
                      <div className={`w-6 h-6 rounded-full ${getMarkerColor(bin.status)} 
                                     border-2 border-white shadow-lg flex items-center justify-center`}>
                        <Trash2 className="w-3 h-3 text-white" />
                      </div>
                      <div className="absolute top-8 left-1/2 transform -translate-x-1/2 
                                      bg-white px-2 py-1 rounded shadow text-xs font-medium whitespace-nowrap">
                        {bin.id}
                      </div>
                    </div>
                  ))}

                  {/* Map Legend */}
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
                    <h3 className="font-semibold text-sm mb-2">Status Legend</h3>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-full bg-success"></div>
                        <span>Good (0-70%)</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-full bg-warning"></div>
                        <span>Warning (71-85%)</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <div className="w-3 h-3 rounded-full bg-destructive"></div>
                        <span>Critical (86-100%)</span>
                      </div>
                    </div>
                  </div>

                  {/* Map Note */}
                  <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
                    <p className="text-xs text-muted-foreground">
                      Click on any dustbin marker to view detailed information
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Dustbin Details Sidebar */}
        <div className="space-y-4">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Dustbin Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedBin ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-lg">{selectedBin.id}</h3>
                    <Badge variant={getStatusColor(selectedBin.status)}>
                      {selectedBin.status.charAt(0).toUpperCase() + selectedBin.status.slice(1)}
                    </Badge>
                  </div>
                  
                  <div className="text-sm text-muted-foreground">
                    <MapPin className="h-3 w-3 inline mr-1" />
                    {selectedBin.location}
                  </div>

                  {/* Fill Level */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Fill Level</span>
                      <span className="font-medium">{selectedBin.fillLevel}%</span>
                    </div>
                    <Progress value={selectedBin.fillLevel} className="h-3" />
                  </div>

                  {/* Technical Details */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-2">
                      <Battery className={`h-4 w-4 ${getBatteryColor(selectedBin.batteryLevel)}`} />
                      <div>
                        <p className="text-xs text-muted-foreground">Battery</p>
                        <p className="font-medium">{selectedBin.batteryLevel}%</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Wifi className={`h-4 w-4 ${getSignalColor(selectedBin.signalStrength)}`} />
                      <div>
                        <p className="text-xs text-muted-foreground">Signal</p>
                        <p className="font-medium">{selectedBin.signalStrength}%</p>
                      </div>
                    </div>
                  </div>

                  {/* Additional Info */}
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Last Emptied:</span>
                      <span>{selectedBin.lastEmptied}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Temperature:</span>
                      <span>{selectedBin.temperature}°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Coordinates:</span>
                      <span className="text-xs">
                        {selectedBin.coordinates.lat.toFixed(4)}, {selectedBin.coordinates.lng.toFixed(4)}
                      </span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-2 pt-4 border-t">
                    <Button className="w-full" size="sm">
                      Schedule Pickup
                    </Button>
                    <Button variant="outline" className="w-full" size="sm">
                      View Full Details
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Trash2 className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">
                    Click on a dustbin marker on the map to view its details
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Total Bins Shown:</span>
                  <span className="font-medium">{dustbins.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Critical Status:</span>
                  <span className="font-medium text-destructive">
                    {dustbins.filter(bin => bin.status === 'critical').length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Warning Status:</span>
                  <span className="font-medium text-warning">
                    {dustbins.filter(bin => bin.status === 'warning').length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Good Status:</span>
                  <span className="font-medium text-success">
                    {dustbins.filter(bin => bin.status === 'good').length}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default MapView;